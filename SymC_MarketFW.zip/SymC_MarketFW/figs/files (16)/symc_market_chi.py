"""
SymC Market χ(t) Extraction Prototype
=====================================
Extracts the damping ratio χ(t) = γ(t)/(2|ω(t)|) from market price data
using the same Hilbert-based method as the seismology paper.

Two modes:
1. Synthetic validation - known damping regime, verify estimator works
2. Real data - apply to actual market returns

Author: SymC Universe Project
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import hilbert, butter, filtfilt, savgol_filter
from scipy.ndimage import uniform_filter1d
import warnings
warnings.filterwarnings('ignore')

# =============================================================================
# CORE χ(t) ESTIMATOR - Same method as seismology paper
# =============================================================================

def extract_chi(signal, fs, band_low, band_high, 
                envelope_smooth_window=None, 
                phase_smooth_window=None,
                min_amplitude_threshold=0.01):
    """
    Extract instantaneous χ(t) from a time series using Hilbert transform.
    
    Parameters:
    -----------
    signal : array
        Input time series (e.g., price returns or log-price displacement)
    fs : float
        Sampling frequency (samples per second/minute/etc.)
    band_low, band_high : float
        Bandpass filter bounds (in same units as fs)
    envelope_smooth_window : int, optional
        Window for envelope smoothing (Savitzky-Golay)
    phase_smooth_window : int, optional  
        Window for phase/frequency smoothing
    min_amplitude_threshold : float
        Minimum envelope amplitude (below this, χ undefined)
        
    Returns:
    --------
    dict with keys:
        't' : time array
        'chi' : instantaneous damping ratio
        'gamma' : instantaneous damping rate
        'omega' : instantaneous angular frequency
        'envelope' : signal envelope A(t)
        'phase' : instantaneous phase φ(t)
        'filtered_signal' : bandpassed signal
    """
    n = len(signal)
    t = np.arange(n) / fs
    
    # Default smoothing windows based on signal length
    if envelope_smooth_window is None:
        envelope_smooth_window = max(11, int(0.05 * n) | 1)  # Ensure odd
    if phase_smooth_window is None:
        phase_smooth_window = max(11, int(0.02 * n) | 1)
    
    # Bandpass filter
    nyq = fs / 2
    low = band_low / nyq
    high = band_high / nyq
    
    # Clamp to valid range
    low = max(0.001, min(low, 0.99))
    high = max(low + 0.01, min(high, 0.999))
    
    b, a = butter(4, [low, high], btype='band')
    filtered = filtfilt(b, a, signal)
    
    # Analytic signal via Hilbert transform
    analytic = hilbert(filtered)
    envelope = np.abs(analytic)
    phase = np.unwrap(np.angle(analytic))
    
    # Smooth envelope before differentiation
    envelope_smooth = savgol_filter(envelope, envelope_smooth_window, 3)
    envelope_smooth = np.maximum(envelope_smooth, 1e-10)  # Prevent log(0)
    
    # Instantaneous frequency: ω(t) = dφ/dt
    phase_smooth = savgol_filter(phase, phase_smooth_window, 3)
    omega = np.gradient(phase_smooth, 1/fs)
    
    # Instantaneous damping: γ(t) = -2 d/dt[ln A(t)]
    log_envelope = np.log(envelope_smooth)
    log_envelope_smooth = savgol_filter(log_envelope, envelope_smooth_window, 3)
    gamma = -2 * np.gradient(log_envelope_smooth, 1/fs)
    
    # χ(t) = γ/(2|ω|)
    omega_abs = np.abs(omega)
    omega_abs = np.maximum(omega_abs, 1e-10)  # Prevent division by zero
    chi = gamma / (2 * omega_abs)
    
    # Mask low-amplitude regions (χ undefined when signal is noise)
    amplitude_mask = envelope_smooth < min_amplitude_threshold * np.max(envelope_smooth)
    chi[amplitude_mask] = np.nan
    
    return {
        't': t,
        'chi': chi,
        'gamma': gamma,
        'omega': omega,
        'envelope': envelope_smooth,
        'phase': phase_smooth,
        'filtered_signal': filtered,
        'amplitude_mask': amplitude_mask
    }


# =============================================================================
# SYNTHETIC VALIDATION - Known damping regime
# =============================================================================

def generate_synthetic_market(fs=100, duration=60, 
                              chi_regimes=[(0, 20, 1.2), (20, 40, 0.7), (40, 60, 0.95)],
                              base_freq=2.0, noise_level=0.1):
    """
    Generate synthetic "market" signal with known χ regimes.
    
    chi_regimes: list of (start_time, end_time, chi_value)
    
    This mimics:
    - χ > 1: Overdamped, rigid market (low vol, slow moves) 
    - χ < 1: Underdamped, chaotic market (oscillations, whipsaw)
    - χ ≈ 1: Critical, adaptive market (efficient price discovery)
    """
    n = int(fs * duration)
    t = np.arange(n) / fs
    signal = np.zeros(n)
    true_chi = np.zeros(n)
    
    omega_0 = 2 * np.pi * base_freq  # Natural frequency
    
    for t_start, t_end, chi_val in chi_regimes:
        mask = (t >= t_start) & (t < t_end)
        gamma = 2 * chi_val * omega_0  # γ = 2χω
        
        # Damped oscillator response to impulse
        t_local = t[mask] - t_start
        
        if chi_val < 1:  # Underdamped - oscillatory
            omega_d = omega_0 * np.sqrt(1 - chi_val**2)
            env = np.exp(-gamma * t_local / 2)
            signal[mask] = env * np.cos(omega_d * t_local)
        elif chi_val == 1:  # Critical
            signal[mask] = (1 + omega_0 * t_local) * np.exp(-omega_0 * t_local)
        else:  # Overdamped - monotonic decay
            # Two real roots
            r1 = -omega_0 * (chi_val - np.sqrt(chi_val**2 - 1))
            r2 = -omega_0 * (chi_val + np.sqrt(chi_val**2 - 1))
            signal[mask] = 0.5 * (np.exp(r1 * t_local) + np.exp(r2 * t_local))
        
        true_chi[mask] = chi_val
    
    # Add noise
    signal += noise_level * np.random.randn(n)
    
    return t, signal, true_chi


def validate_synthetic():
    """Run synthetic validation to verify estimator works."""
    print("=" * 60)
    print("SYNTHETIC VALIDATION")
    print("Testing χ(t) estimator on known damping regimes")
    print("=" * 60)
    
    fs = 100  # 100 samples/sec
    duration = 60  # 60 seconds
    
    # Three regimes: overdamped → underdamped → critical
    chi_regimes = [
        (0, 20, 1.3),    # Overdamped (rigid market)
        (20, 40, 0.6),   # Underdamped (chaotic/volatile)
        (40, 60, 0.9),   # Near-critical (adaptive)
    ]
    
    t, signal, true_chi = generate_synthetic_market(
        fs=fs, duration=duration, 
        chi_regimes=chi_regimes,
        base_freq=2.0, 
        noise_level=0.05
    )
    
    # Extract χ(t)
    result = extract_chi(
        signal, fs, 
        band_low=1.0, band_high=4.0,  # Centered on 2 Hz carrier
        envelope_smooth_window=51,
        phase_smooth_window=21
    )
    
    # Plot results
    fig, axes = plt.subplots(4, 1, figsize=(12, 10), sharex=True)
    
    # Raw signal
    axes[0].plot(t, signal, 'b-', alpha=0.7, lw=0.5)
    axes[0].set_ylabel('Signal')
    axes[0].set_title('Synthetic Market Signal with Known χ Regimes')
    
    # Envelope
    axes[1].plot(result['t'], result['envelope'], 'g-', lw=1.5)
    axes[1].set_ylabel('Envelope A(t)')
    axes[1].set_yscale('log')
    
    # Instantaneous frequency
    axes[2].plot(result['t'], result['omega']/(2*np.pi), 'purple', lw=1)
    axes[2].axhline(2.0, color='gray', ls='--', label='True freq = 2 Hz')
    axes[2].set_ylabel('Freq ω/(2π) [Hz]')
    axes[2].set_ylim(0, 5)
    axes[2].legend()
    
    # χ(t) - the key result
    axes[3].plot(result['t'], result['chi'], 'r-', lw=1.5, label='Estimated χ(t)')
    axes[3].step(t, true_chi, 'k--', lw=2, where='post', label='True χ')
    axes[3].axhline(1.0, color='blue', ls=':', lw=2, label='χ = 1 boundary')
    axes[3].axhspan(0.8, 1.0, alpha=0.2, color='green', label='Adaptive window')
    axes[3].set_ylabel('χ(t)')
    axes[3].set_xlabel('Time (s)')
    axes[3].set_ylim(-0.5, 2.5)
    axes[3].legend(loc='upper right')
    
    # Add regime labels
    for t_start, t_end, chi_val in chi_regimes:
        regime = 'Overdamped' if chi_val > 1 else ('Underdamped' if chi_val < 1 else 'Critical')
        axes[3].annotate(f'{regime}\nχ={chi_val}', 
                        xy=((t_start+t_end)/2, 2.2), ha='center', fontsize=9)
    
    plt.tight_layout()
    plt.savefig('/home/claude/synthetic_chi_validation.png', dpi=150, bbox_inches='tight')
    plt.close()
    
    print(f"\nResults saved to: /home/claude/synthetic_chi_validation.png")
    
    # Compute estimation accuracy
    valid_mask = ~np.isnan(result['chi'])
    estimated = result['chi'][valid_mask]
    true_interp = np.interp(result['t'][valid_mask], t, true_chi)
    
    print(f"\nEstimation accuracy (excluding edges/transitions):")
    for t_start, t_end, chi_val in chi_regimes:
        regime_mask = (result['t'] >= t_start + 5) & (result['t'] < t_end - 5)
        regime_mask &= valid_mask
        if regime_mask.sum() > 0:
            mean_est = np.nanmean(result['chi'][regime_mask])
            std_est = np.nanstd(result['chi'][regime_mask])
            print(f"  χ={chi_val:.1f} regime: estimated {mean_est:.2f} ± {std_est:.2f}")
    
    return result


# =============================================================================
# MARKET DATA APPLICATION
# =============================================================================

def generate_mock_market_data(regime='normal', n_points=5000, fs=1.0):
    """
    Generate mock market returns mimicking different regimes.
    
    regime: 'normal', 'crash', 'frozen', 'volatile'
    fs: samples per minute (1.0 = minute bars)
    """
    t = np.arange(n_points) / fs
    
    if regime == 'normal':
        # Adaptive market: mean-reverting with moderate vol
        # χ ≈ 0.9 expected
        omega = 0.1  # Slow oscillation (about 1 hour period)
        gamma = 0.18  # γ = 2χω → χ ≈ 0.9
        noise = 0.02
        
    elif regime == 'crash':
        # Underdamped: oscillations, whipsaw
        # χ ≈ 0.5 expected  
        omega = 0.15
        gamma = 0.15  # γ = 2χω → χ ≈ 0.5
        noise = 0.05
        
    elif regime == 'frozen':
        # Overdamped: rigid, slow response
        # χ ≈ 1.5 expected
        omega = 0.05
        gamma = 0.15  # γ = 2χω → χ ≈ 1.5
        noise = 0.005
        
    elif regime == 'volatile':
        # Highly underdamped: ringing
        # χ ≈ 0.3 expected
        omega = 0.2
        gamma = 0.12  # γ = 2χω → χ ≈ 0.3
        noise = 0.08
    else:
        raise ValueError(f"Unknown regime: {regime}")
    
    # Generate damped oscillator + noise
    chi = gamma / (2 * omega)
    
    if chi < 1:
        omega_d = omega * np.sqrt(1 - chi**2)
        signal = np.exp(-gamma * t / 2) * np.cos(omega_d * t)
    else:
        r1 = -omega * (chi - np.sqrt(chi**2 - 1))
        r2 = -omega * (chi + np.sqrt(chi**2 - 1))
        signal = 0.5 * (np.exp(r1 * t) + np.exp(r2 * t))
    
    # Add multiple impulses to simulate ongoing trading
    n_impulses = 20
    for i in range(n_impulses):
        t_impulse = np.random.randint(100, n_points - 500)
        amplitude = np.random.uniform(0.5, 1.5)
        t_local = np.maximum(t - t[t_impulse], 0)
        
        if chi < 1:
            response = amplitude * np.exp(-gamma * t_local / 2) * np.cos(omega_d * t_local)
        else:
            response = amplitude * 0.5 * (np.exp(r1 * t_local) + np.exp(r2 * t_local))
        
        response[t < t[t_impulse]] = 0
        signal += response
    
    # Add noise
    signal += noise * np.random.randn(n_points)
    
    return t, signal, chi


def compare_market_regimes():
    """Compare χ extraction across different market regimes."""
    print("\n" + "=" * 60)
    print("MARKET REGIME COMPARISON")
    print("Comparing χ(t) across simulated market conditions")
    print("=" * 60)
    
    regimes = ['normal', 'crash', 'frozen', 'volatile']
    expected_chi = {'normal': 0.9, 'crash': 0.5, 'frozen': 1.5, 'volatile': 0.3}
    
    fig, axes = plt.subplots(len(regimes), 2, figsize=(14, 12))
    
    results = {}
    
    for i, regime in enumerate(regimes):
        t, signal, true_chi = generate_mock_market_data(regime=regime, n_points=3000, fs=1.0)
        
        # Extract χ(t)
        result = extract_chi(
            signal, fs=1.0,
            band_low=0.01, band_high=0.3,  # Low freq for minute data
            envelope_smooth_window=101,
            phase_smooth_window=51
        )
        
        results[regime] = result
        
        # Plot signal
        axes[i, 0].plot(t, signal, 'b-', alpha=0.7, lw=0.5)
        axes[i, 0].set_ylabel(f'{regime.upper()}\nPrice')
        if i == 0:
            axes[i, 0].set_title('Simulated Price Displacement')
        
        # Plot χ(t)
        valid = ~np.isnan(result['chi'])
        axes[i, 1].plot(result['t'][valid], result['chi'][valid], 'r-', lw=1, alpha=0.7)
        axes[i, 1].axhline(1.0, color='blue', ls='--', lw=2, label='χ=1')
        axes[i, 1].axhline(expected_chi[regime], color='green', ls=':', lw=2, 
                          label=f'Expected χ={expected_chi[regime]}')
        axes[i, 1].axhspan(0.8, 1.0, alpha=0.15, color='green')
        axes[i, 1].set_ylabel('χ(t)')
        axes[i, 1].set_ylim(-0.5, 3.0)
        axes[i, 1].legend(loc='upper right', fontsize=8)
        if i == 0:
            axes[i, 1].set_title('Estimated Damping Ratio χ(t)')
        
        # Stats
        chi_valid = result['chi'][valid]
        mean_chi = np.nanmean(chi_valid)
        std_chi = np.nanstd(chi_valid)
        print(f"\n{regime.upper()} regime:")
        print(f"  Expected χ = {expected_chi[regime]:.2f}")
        print(f"  Estimated χ = {mean_chi:.2f} ± {std_chi:.2f}")
        
    axes[-1, 0].set_xlabel('Time (minutes)')
    axes[-1, 1].set_xlabel('Time (minutes)')
    
    plt.tight_layout()
    plt.savefig('/home/claude/market_regime_comparison.png', dpi=150, bbox_inches='tight')
    plt.close()
    
    print(f"\nResults saved to: /home/claude/market_regime_comparison.png")
    
    return results


# =============================================================================
# REAL DATA HOOKS (for when you have actual market data)
# =============================================================================

def load_market_data_placeholder():
    """
    Placeholder for loading real market data.
    
    To use with real data, replace this with:
    - yfinance for daily/minute data
    - lobster for LOB data  
    - Your own tick data source
    
    Returns price returns (not prices) for χ extraction.
    """
    print("\n[NOTE] This is a placeholder. For real data, install yfinance:")
    print("  pip install yfinance --break-system-packages")
    print("\nThen modify this function to load actual data.")
    
    # Generate realistic-looking returns as placeholder
    np.random.seed(42)
    n = 2000
    
    # GARCH-like returns with regime switching
    returns = np.zeros(n)
    vol = 0.01
    
    for i in range(1, n):
        # Regime switch occasionally
        if np.random.rand() < 0.01:
            vol = np.random.choice([0.005, 0.01, 0.02, 0.03])
        
        # GARCH-like vol clustering
        vol = 0.9 * vol + 0.1 * np.abs(returns[i-1]) + 0.001
        returns[i] = vol * np.random.randn()
    
    return np.arange(n), returns


def analyze_real_market_data():
    """
    Template for analyzing real market data.
    Modify load_market_data_placeholder() first.
    """
    print("\n" + "=" * 60)
    print("REAL MARKET DATA ANALYSIS (Placeholder)")
    print("=" * 60)
    
    t, returns = load_market_data_placeholder()
    
    # Cumulative returns → price displacement
    price_displacement = np.cumsum(returns)
    
    # Extract χ(t)
    result = extract_chi(
        price_displacement, 
        fs=1.0,  # Assuming minute bars
        band_low=0.005, 
        band_high=0.1,
        envelope_smooth_window=101,
        phase_smooth_window=51
    )
    
    # Plot
    fig, axes = plt.subplots(3, 1, figsize=(12, 8), sharex=True)
    
    axes[0].plot(t, price_displacement, 'b-', lw=0.5)
    axes[0].set_ylabel('Price Displacement')
    axes[0].set_title('Market χ(t) Analysis (Placeholder Data)')
    
    axes[1].plot(result['t'], result['envelope'], 'g-', lw=1)
    axes[1].set_ylabel('Envelope')
    axes[1].set_yscale('log')
    
    valid = ~np.isnan(result['chi'])
    axes[2].plot(result['t'][valid], result['chi'][valid], 'r-', lw=1, alpha=0.7)
    axes[2].axhline(1.0, color='blue', ls='--', lw=2, label='χ=1 (critical)')
    axes[2].axhspan(0.8, 1.0, alpha=0.2, color='green', label='Adaptive window')
    axes[2].set_ylabel('χ(t)')
    axes[2].set_xlabel('Time')
    axes[2].set_ylim(-1, 4)
    axes[2].legend()
    
    plt.tight_layout()
    plt.savefig('/home/claude/real_market_chi.png', dpi=150, bbox_inches='tight')
    plt.close()
    
    # Distribution of χ
    chi_valid = result['chi'][valid]
    print(f"\nχ(t) Statistics:")
    print(f"  Mean: {np.nanmean(chi_valid):.3f}")
    print(f"  Median: {np.nanmedian(chi_valid):.3f}")
    print(f"  Std: {np.nanstd(chi_valid):.3f}")
    print(f"  % in adaptive window [0.8, 1.0]: {100*np.mean((chi_valid >= 0.8) & (chi_valid <= 1.0)):.1f}%")
    
    print(f"\nResults saved to: /home/claude/real_market_chi.png")
    
    return result


# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    print("SymC Market χ(t) Extraction Prototype")
    print("=" * 60)
    
    # 1. Validate on synthetic data first
    synthetic_result = validate_synthetic()
    
    # 2. Compare across market regimes  
    regime_results = compare_market_regimes()
    
    # 3. Template for real data
    real_result = analyze_real_market_data()
    
    print("\n" + "=" * 60)
    print("VALIDATION COMPLETE")
    print("=" * 60)
    print("\nKey outputs:")
    print("  1. synthetic_chi_validation.png - Estimator validation")
    print("  2. market_regime_comparison.png - Regime differentiation")
    print("  3. real_market_chi.png - Template for real data")
    print("\nNext steps:")
    print("  - Install yfinance: pip install yfinance --break-system-packages")
    print("  - Modify load_market_data_placeholder() for real data")
    print("  - Test on SPY, sector ETFs, or individual stocks")
