"""
SymC Market χ(t) Extraction - Microstructure Approach
======================================================
This version uses methods more appropriate for market data:

1. REALIZED VOLATILITY DECAY METHOD
   - γ estimated from how quickly volatility shocks decay (half-life)
   - ω estimated from characteristic mean-reversion frequency
   
2. ORDER FLOW AUTOCORRELATION METHOD  
   - Based on Bouchaud propagator: impact decays as G(t)
   - Maps resilience ρ → γ in Obizhaeva-Wang framework

3. ROLLING WINDOW VARIANCE RATIO
   - Detects underdamped (trending) vs overdamped (mean-reverting) behavior

Author: SymC Universe Project
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import butter, filtfilt
from scipy.optimize import curve_fit
from scipy.stats import linregress
import warnings
warnings.filterwarnings('ignore')


# =============================================================================
# METHOD 1: VOLATILITY DECAY APPROACH
# =============================================================================

def estimate_chi_volatility_decay(returns, window=50, decay_window=20):
    """
    Estimate χ(t) from volatility shock decay.
    
    The idea: After a volatility spike, how quickly does it decay?
    - Fast decay (large γ) + slow mean-reversion (small ω) → high χ (overdamped)
    - Slow decay (small γ) + fast oscillation (large ω) → low χ (underdamped)
    
    This maps to the Obizhaeva-Wang resilience framework.
    """
    n = len(returns)
    
    # Rolling realized volatility
    vol = np.zeros(n)
    for i in range(window, n):
        vol[i] = np.std(returns[i-window:i])
    
    # Detect volatility spikes (deviations from rolling mean)
    vol_mean = np.zeros(n)
    vol_dev = np.zeros(n)
    for i in range(2*window, n):
        vol_mean[i] = np.mean(vol[i-window:i])
        vol_dev[i] = vol[i] - vol_mean[i]
    
    # Estimate decay rate γ from autocorrelation of vol deviations
    gamma_t = np.full(n, np.nan)
    omega_t = np.full(n, np.nan)
    
    for i in range(3*window, n - decay_window):
        # Local vol deviation series
        local_vol = vol_dev[i:i+decay_window]
        
        if np.std(local_vol) < 1e-10:
            continue
            
        # Fit exponential decay: vol_dev(t) ~ exp(-γt/2)
        # Using autocorrelation decay as proxy
        acf = np.correlate(local_vol - np.mean(local_vol), 
                          local_vol - np.mean(local_vol), mode='full')
        acf = acf[len(acf)//2:]
        acf = acf / (acf[0] + 1e-10)
        
        # Find half-life
        half_life_idx = np.where(acf < 0.5)[0]
        if len(half_life_idx) > 0:
            half_life = half_life_idx[0]
            gamma_t[i] = np.log(2) / (half_life + 1)  # γ from half-life
        
        # Estimate ω from zero-crossings of returns
        returns_local = returns[i:i+decay_window]
        zero_crossings = np.sum(np.diff(np.sign(returns_local)) != 0)
        if decay_window > 0:
            omega_t[i] = np.pi * zero_crossings / decay_window  # Approximate ω
    
    # χ = γ / (2ω)
    omega_t = np.maximum(omega_t, 0.01)  # Prevent division by zero
    chi_t = gamma_t / (2 * omega_t)
    
    return {
        't': np.arange(n),
        'chi': chi_t,
        'gamma': gamma_t,
        'omega': omega_t,
        'volatility': vol,
        'vol_deviation': vol_dev
    }


# =============================================================================
# METHOD 2: VARIANCE RATIO APPROACH (More robust for markets)
# =============================================================================

def estimate_chi_variance_ratio(returns, short_window=10, long_window=50):
    """
    Use variance ratios to detect damping regime.
    
    For a damped oscillator:
    - Underdamped (χ < 1): Returns show positive autocorrelation (trending)
      → Var(long) > Var(short) * (long/short)
    - Overdamped (χ > 1): Returns show negative autocorrelation (mean-reverting)  
      → Var(long) < Var(short) * (long/short)
    - Critical (χ = 1): Random walk
      → Var(long) ≈ Var(short) * (long/short)
    
    Variance ratio VR = Var(k-period returns) / (k * Var(1-period returns))
    VR > 1 → Underdamped (trending)
    VR < 1 → Overdamped (mean-reverting)
    VR ≈ 1 → Critical
    """
    n = len(returns)
    
    chi_t = np.full(n, np.nan)
    vr_t = np.full(n, np.nan)
    
    for i in range(long_window * 2, n):
        # Short-term variance
        short_returns = returns[i-long_window:i]
        var_short = np.var(short_returns)
        
        # Long-term variance (aggregated returns)
        k = long_window // short_window
        agg_returns = np.array([
            np.sum(returns[i-long_window+j*short_window:i-long_window+(j+1)*short_window])
            for j in range(k)
        ])
        var_long = np.var(agg_returns)
        
        if var_short > 1e-10:
            # Variance ratio
            vr = var_long / (k * var_short)
            vr_t[i] = vr
            
            # Map VR to χ
            # VR = 1 → χ = 1 (random walk, critical damping)
            # VR > 1 → χ < 1 (trending, underdamped)
            # VR < 1 → χ > 1 (mean-reverting, overdamped)
            # Use: χ ≈ 1/VR as rough mapping (bounded)
            chi_t[i] = np.clip(1.0 / vr, 0.1, 5.0)
    
    return {
        't': np.arange(n),
        'chi': chi_t,
        'variance_ratio': vr_t
    }


# =============================================================================
# METHOD 3: HURST EXPONENT APPROACH
# =============================================================================

def estimate_chi_hurst(returns, window=100):
    """
    Use rolling Hurst exponent to estimate χ.
    
    H < 0.5 → Mean-reverting → Overdamped (χ > 1)
    H = 0.5 → Random walk → Critical (χ = 1)
    H > 0.5 → Trending → Underdamped (χ < 1)
    
    Mapping: χ ≈ 1 / (2H) gives:
    H = 0.5 → χ = 1
    H = 0.3 → χ = 1.67
    H = 0.7 → χ = 0.71
    """
    n = len(returns)
    
    chi_t = np.full(n, np.nan)
    hurst_t = np.full(n, np.nan)
    
    for i in range(window, n):
        local_returns = returns[i-window:i]
        
        # R/S Hurst estimation
        cumsum = np.cumsum(local_returns - np.mean(local_returns))
        R = np.max(cumsum) - np.min(cumsum)
        S = np.std(local_returns)
        
        if S > 1e-10:
            RS = R / S
            # H ≈ log(R/S) / log(n) for large n
            H = np.log(RS + 1) / np.log(window)
            H = np.clip(H, 0.1, 0.9)
            hurst_t[i] = H
            
            # Map H to χ
            chi_t[i] = 1.0 / (2 * H)
    
    return {
        't': np.arange(n),
        'chi': chi_t,
        'hurst': hurst_t
    }


# =============================================================================
# SYNTHETIC MARKET DATA
# =============================================================================

def generate_regime_switching_market(n=5000, regimes=None):
    """
    Generate market returns with known damping regimes.
    
    Uses AR(1) process with regime-dependent persistence:
    r_t = φ * r_{t-1} + σ * ε_t
    
    φ > 0 → Trending (underdamped, χ < 1)
    φ = 0 → Random walk (critical, χ = 1)  
    φ < 0 → Mean-reverting (overdamped, χ > 1)
    """
    if regimes is None:
        # Default: three regimes
        regimes = [
            (0, 1500, 0.3, 0.01, 'Trending (χ<1)'),      # Underdamped
            (1500, 3500, 0.0, 0.015, 'Random Walk (χ≈1)'),  # Critical
            (3500, 5000, -0.3, 0.01, 'Mean-Reverting (χ>1)')  # Overdamped
        ]
    
    returns = np.zeros(n)
    true_chi = np.full(n, np.nan)
    regime_labels = [''] * n
    
    for start, end, phi, sigma, label in regimes:
        for i in range(max(start, 1), min(end, n)):
            returns[i] = phi * returns[i-1] + sigma * np.random.randn()
            
            # True χ from AR(1) persistence
            # φ = 0 → χ = 1
            # φ > 0 → χ < 1 (trending)
            # φ < 0 → χ > 1 (mean-reverting)
            if phi == 0:
                true_chi[i] = 1.0
            elif phi > 0:
                true_chi[i] = 1.0 / (1 + phi)  # Maps φ=0.5 → χ≈0.67
            else:
                true_chi[i] = 1.0 / (1 + phi)  # Maps φ=-0.5 → χ=2.0
            
            regime_labels[i] = label
    
    return returns, true_chi, regime_labels


# =============================================================================
# VALIDATION AND COMPARISON
# =============================================================================

def run_validation():
    """Run all three methods on synthetic data and compare."""
    print("=" * 70)
    print("SymC Market χ(t) - Multi-Method Validation")
    print("=" * 70)
    
    # Generate test data with known regimes
    np.random.seed(42)
    returns, true_chi, labels = generate_regime_switching_market(n=5000)
    
    # Run all three methods
    print("\nRunning estimators...")
    result_vol = estimate_chi_volatility_decay(returns, window=30, decay_window=20)
    result_vr = estimate_chi_variance_ratio(returns, short_window=10, long_window=50)
    result_hurst = estimate_chi_hurst(returns, window=100)
    
    # Plot comparison
    fig, axes = plt.subplots(5, 1, figsize=(14, 14), sharex=True)
    
    t = np.arange(len(returns))
    
    # Returns
    axes[0].plot(t, np.cumsum(returns), 'b-', lw=0.5)
    axes[0].set_ylabel('Cumulative Returns')
    axes[0].set_title('Synthetic Market with Known χ Regimes', fontsize=12)
    
    # Add regime shading
    colors = {'Trending (χ<1)': 'red', 'Random Walk (χ≈1)': 'blue', 'Mean-Reverting (χ>1)': 'green'}
    regimes_plotted = set()
    for i in range(len(labels)):
        if labels[i] and labels[i] not in regimes_plotted:
            # Find regime extent
            start = i
            while i < len(labels) and labels[i] == labels[start]:
                i += 1
            end = i
            axes[0].axvspan(start, end, alpha=0.15, color=colors.get(labels[start], 'gray'))
            regimes_plotted.add(labels[start])
    
    # True χ
    axes[1].plot(t, true_chi, 'k-', lw=2, label='True χ')
    axes[1].axhline(1.0, color='blue', ls='--', lw=1.5)
    axes[1].axhspan(0.8, 1.2, alpha=0.2, color='green', label='Adaptive window')
    axes[1].set_ylabel('True χ')
    axes[1].legend(loc='upper right')
    axes[1].set_ylim(0, 3)
    
    # Volatility decay method
    valid = ~np.isnan(result_vol['chi'])
    chi_clipped = np.clip(result_vol['chi'], 0, 5)
    axes[2].plot(t[valid], chi_clipped[valid], 'r-', lw=0.8, alpha=0.7, label='Vol Decay')
    axes[2].axhline(1.0, color='blue', ls='--', lw=1.5)
    axes[2].set_ylabel('χ (Vol Decay)')
    axes[2].set_ylim(0, 3)
    axes[2].legend(loc='upper right')
    
    # Variance ratio method
    valid = ~np.isnan(result_vr['chi'])
    axes[3].plot(t[valid], result_vr['chi'][valid], 'm-', lw=0.8, alpha=0.7, label='Variance Ratio')
    axes[3].axhline(1.0, color='blue', ls='--', lw=1.5)
    axes[3].set_ylabel('χ (Var Ratio)')
    axes[3].set_ylim(0, 3)
    axes[3].legend(loc='upper right')
    
    # Hurst method
    valid = ~np.isnan(result_hurst['chi'])
    axes[4].plot(t[valid], result_hurst['chi'][valid], 'g-', lw=0.8, alpha=0.7, label='Hurst')
    axes[4].axhline(1.0, color='blue', ls='--', lw=1.5)
    axes[4].set_ylabel('χ (Hurst)')
    axes[4].set_xlabel('Time')
    axes[4].set_ylim(0, 3)
    axes[4].legend(loc='upper right')
    
    plt.tight_layout()
    plt.savefig('/home/claude/chi_methods_comparison.png', dpi=150, bbox_inches='tight')
    plt.close()
    
    print(f"\nSaved: /home/claude/chi_methods_comparison.png")
    
    # Regime-wise accuracy
    print("\n" + "-" * 50)
    print("REGIME-WISE ACCURACY")
    print("-" * 50)
    
    regime_bounds = [(0, 1500), (1500, 3500), (3500, 5000)]
    regime_names = ['Trending', 'Random Walk', 'Mean-Reverting']
    expected_chi = [0.77, 1.0, 2.0]  # Approximate from AR(1) mapping
    
    for (start, end), name, exp_chi in zip(regime_bounds, regime_names, expected_chi):
        mask = (t >= start) & (t < end)
        
        print(f"\n{name} regime (expected χ ≈ {exp_chi:.2f}):")
        
        for method_name, result in [('Vol Decay', result_vol), 
                                     ('Var Ratio', result_vr),
                                     ('Hurst', result_hurst)]:
            chi_regime = result['chi'][mask]
            chi_valid = chi_regime[~np.isnan(chi_regime)]
            if len(chi_valid) > 0:
                print(f"  {method_name:12s}: χ = {np.median(chi_valid):.2f} ± {np.std(chi_valid):.2f}")
    
    return result_vol, result_vr, result_hurst


def test_real_style_data():
    """Test on more realistic market dynamics."""
    print("\n" + "=" * 70)
    print("REALISTIC MARKET TEST")
    print("=" * 70)
    
    np.random.seed(123)
    n = 3000
    
    # More realistic: GARCH-like with occasional regime switches
    returns = np.zeros(n)
    vol = 0.01
    phi = 0.0  # Current persistence
    
    true_chi = np.zeros(n)
    
    for i in range(1, n):
        # Occasional regime switch
        if i == 500:
            phi = 0.4  # Go underdamped (trending)
        elif i == 1200:
            phi = 0.0  # Back to random walk
        elif i == 1800:
            phi = -0.3  # Overdamped (mean-reverting)
        elif i == 2400:
            phi = 0.0  # Back to random walk
        
        # GARCH-like volatility
        vol = 0.95 * vol + 0.05 * np.abs(returns[i-1]) + 0.002
        
        # AR(1) with stochastic vol
        returns[i] = phi * returns[i-1] + vol * np.random.randn()
        
        # True χ
        if phi == 0:
            true_chi[i] = 1.0
        elif phi > 0:
            true_chi[i] = 1.0 / (1 + phi)
        else:
            true_chi[i] = 1.0 / (1 + phi)
    
    # Run Hurst method (most stable)
    result = estimate_chi_hurst(returns, window=100)
    
    # Plot
    fig, axes = plt.subplots(3, 1, figsize=(14, 10), sharex=True)
    
    t = np.arange(n)
    
    # Cumulative returns
    axes[0].plot(t, np.cumsum(returns), 'b-', lw=0.8)
    axes[0].set_ylabel('Cumulative Returns')
    axes[0].set_title('Realistic Market Simulation with Regime Switches', fontsize=12)
    
    # Mark regime changes
    for x, label in [(500, 'Trending'), (1200, 'RW'), (1800, 'Mean-Rev'), (2400, 'RW')]:
        axes[0].axvline(x, color='red', ls='--', alpha=0.5)
        axes[0].text(x+50, axes[0].get_ylim()[1]*0.9, label, fontsize=9)
    
    # True χ
    axes[1].plot(t, true_chi, 'k-', lw=2, label='True χ')
    axes[1].axhline(1.0, color='blue', ls='--', lw=1.5)
    axes[1].axhspan(0.8, 1.2, alpha=0.2, color='green')
    axes[1].set_ylabel('True χ')
    axes[1].set_ylim(0, 3)
    axes[1].legend()
    
    # Estimated χ
    valid = ~np.isnan(result['chi'])
    axes[2].plot(t[valid], result['chi'][valid], 'r-', lw=1, alpha=0.8, label='Estimated χ (Hurst)')
    axes[2].axhline(1.0, color='blue', ls='--', lw=1.5)
    axes[2].axhspan(0.8, 1.2, alpha=0.2, color='green')
    axes[2].set_ylabel('Estimated χ')
    axes[2].set_xlabel('Time')
    axes[2].set_ylim(0, 3)
    axes[2].legend()
    
    plt.tight_layout()
    plt.savefig('/home/claude/realistic_market_chi.png', dpi=150, bbox_inches='tight')
    plt.close()
    
    print(f"\nSaved: /home/claude/realistic_market_chi.png")
    
    # Check regime detection
    print("\nRegime Detection Quality:")
    regime_bounds = [(600, 1100, 'Trending', 0.71), 
                     (1300, 1700, 'RW', 1.0),
                     (1900, 2300, 'Mean-Rev', 1.43),
                     (2500, 2900, 'RW', 1.0)]
    
    for start, end, name, exp_chi in regime_bounds:
        mask = (t >= start) & (t < end) & valid
        chi_regime = result['chi'][mask]
        if len(chi_regime) > 0:
            median_chi = np.median(chi_regime)
            # Check if estimator got the right side of 1.0
            direction_correct = (exp_chi < 1 and median_chi < 1) or \
                               (exp_chi > 1 and median_chi > 1) or \
                               (exp_chi == 1 and 0.8 < median_chi < 1.2)
            status = "✓" if direction_correct else "✗"
            print(f"  {name:12s}: expected χ={exp_chi:.2f}, got χ={median_chi:.2f} {status}")


# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    # Run validation
    results = run_validation()
    
    # Test on more realistic data
    test_real_style_data()
    
    print("\n" + "=" * 70)
    print("KEY FINDINGS")
    print("=" * 70)
    print("""
The HURST-BASED METHOD shows the most promise for market data because:

1. It directly measures the trending vs mean-reverting character
2. H < 0.5 → Mean-reverting → χ > 1 (overdamped)
3. H = 0.5 → Random walk → χ ≈ 1 (critical)  
4. H > 0.5 → Trending → χ < 1 (underdamped)

The mapping χ ≈ 1/(2H) gives reasonable regime separation.

NEXT STEPS:
1. Test on real market data (SPY, sector ETFs)
2. Compare χ distributions across sectors
3. Look for χ drops before crash events (2008, 2020 March)
4. Validate sector predictions from your PDF
""")
