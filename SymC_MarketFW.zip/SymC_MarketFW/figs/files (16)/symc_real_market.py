"""
SymC Market χ - Real Data Validation
=====================================
Test the Hurst-based χ estimator on actual market data.

Goals:
1. Validate sector predictions from the SymC Stability Mapping paper
2. Look for χ dynamics around crash events (2008, 2020)
3. Compare sector χ distributions

Expected results (from SymC Stability Mapping paper):
- Energy, Materials, Small Caps: χ ≈ 0.7 (underdamped/chaotic)
- Tech, Financials, Healthcare: χ ≈ 0.9-1.0 (adaptive)
- Utilities, Consumer Staples: χ ≈ 1.2-1.3 (overdamped/rigid)

Author: SymC Universe Project
"""

import numpy as np
import matplotlib.pyplot as plt
import yfinance as yf
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')


def estimate_chi_hurst(returns, window=100):
    """
    Use rolling Hurst exponent to estimate χ.
    
    H < 0.5 → Mean-reverting → Overdamped (χ > 1)
    H = 0.5 → Random walk → Critical (χ = 1)
    H > 0.5 → Trending → Underdamped (χ < 1)
    
    Mapping: χ ≈ 1 / (2H)
    """
    n = len(returns)
    
    chi_t = np.full(n, np.nan)
    hurst_t = np.full(n, np.nan)
    
    for i in range(window, n):
        local_returns = returns[i-window:i]
        
        # R/S Hurst estimation
        cumsum = np.cumsum(local_returns - np.mean(local_returns))
        R = np.max(cumsum) - np.min(cumsum)
        S = np.std(local_returns)
        
        if S > 1e-10 and R > 1e-10:
            RS = R / S
            H = np.log(RS + 1) / np.log(window)
            H = np.clip(H, 0.2, 0.8)  # Bound to reasonable range
            hurst_t[i] = H
            chi_t[i] = 1.0 / (2 * H)
    
    return chi_t, hurst_t


def get_sector_data(period='2y'):
    """Download sector ETF data."""
    
    # Sector ETFs mapping
    sectors = {
        'XLK': 'Technology',
        'XLF': 'Financials', 
        'XLE': 'Energy',
        'XLV': 'Healthcare',
        'XLI': 'Industrials',
        'XLP': 'Consumer Staples',
        'XLY': 'Consumer Discretionary',
        'XLU': 'Utilities',
        'XLRE': 'Real Estate',
        'XLB': 'Materials',
        'XLC': 'Communication Services',
        'IWM': 'Small Cap (Russell 2000)',
        'SPY': 'S&P 500'
    }
    
    data = {}
    print("Downloading sector ETF data...")
    
    for ticker, name in sectors.items():
        try:
            df = yf.download(ticker, period=period, progress=False)
            if len(df) > 100:
                returns = df['Adj Close'].pct_change().dropna().values
                data[name] = {
                    'ticker': ticker,
                    'returns': returns,
                    'prices': df['Adj Close'].values,
                    'dates': df.index
                }
                print(f"  ✓ {name} ({ticker}): {len(returns)} days")
        except Exception as e:
            print(f"  ✗ {name} ({ticker}): {e}")
    
    return data


def analyze_sector_chi(data, window=60):
    """Compute χ for each sector and compare to predictions."""
    
    print("\n" + "=" * 70)
    print("SECTOR χ ANALYSIS")
    print("=" * 70)
    
    # Expected χ from SymC Stability Mapping paper
    expected = {
        'Technology': 0.9,
        'Financials': 1.0,
        'Energy': 0.7,
        'Healthcare': 1.0,
        'Industrials': 0.9,
        'Consumer Staples': 1.2,
        'Consumer Discretionary': 0.8,
        'Utilities': 1.3,
        'Real Estate': 0.8,
        'Materials': 0.7,
        'Communication Services': 0.9,
        'Small Cap (Russell 2000)': 0.7,
        'S&P 500': 0.9
    }
    
    results = {}
    
    for name, sector_data in data.items():
        returns = sector_data['returns']
        chi_t, hurst_t = estimate_chi_hurst(returns, window=window)
        
        valid_chi = chi_t[~np.isnan(chi_t)]
        if len(valid_chi) > 0:
            median_chi = np.median(valid_chi)
            mean_chi = np.mean(valid_chi)
            std_chi = np.std(valid_chi)
            
            results[name] = {
                'chi_t': chi_t,
                'hurst_t': hurst_t,
                'median': median_chi,
                'mean': mean_chi,
                'std': std_chi,
                'expected': expected.get(name, 1.0)
            }
    
    # Print comparison table
    print(f"\n{'Sector':<30} {'Expected χ':>12} {'Measured χ':>12} {'Match':>8}")
    print("-" * 70)
    
    for name in sorted(results.keys(), key=lambda x: results[x]['expected']):
        r = results[name]
        exp = r['expected']
        meas = r['median']
        
        # Check if direction matches (both < 1, both > 1, or both ≈ 1)
        if exp < 0.9:
            match = "✓" if meas < 1.0 else "✗"
        elif exp > 1.1:
            match = "✓" if meas > 1.0 else "✗"
        else:
            match = "✓" if 0.85 < meas < 1.15 else "~"
        
        print(f"{name:<30} {exp:>12.2f} {meas:>12.2f} {match:>8}")
    
    return results


def plot_sector_comparison(results, data):
    """Create comparison plot of sector χ values."""
    
    # Sort by expected χ
    sorted_sectors = sorted(results.keys(), key=lambda x: results[x]['expected'])
    
    fig, axes = plt.subplots(2, 1, figsize=(14, 10))
    
    # Bar chart comparison
    x = np.arange(len(sorted_sectors))
    expected = [results[s]['expected'] for s in sorted_sectors]
    measured = [results[s]['median'] for s in sorted_sectors]
    errors = [results[s]['std'] for s in sorted_sectors]
    
    width = 0.35
    axes[0].bar(x - width/2, expected, width, label='Expected (SymC Paper)', color='blue', alpha=0.7)
    axes[0].bar(x + width/2, measured, width, label='Measured (Hurst)', color='red', alpha=0.7,
                yerr=errors, capsize=3)
    
    axes[0].axhline(1.0, color='green', ls='--', lw=2, label='χ = 1 (Critical)')
    axes[0].axhspan(0.8, 1.0, alpha=0.1, color='green')
    
    axes[0].set_ylabel('χ (Damping Ratio)')
    axes[0].set_title('SymC Sector Stability Mapping: Expected vs Measured', fontsize=12)
    axes[0].set_xticks(x)
    axes[0].set_xticklabels([s.replace(' ', '\n') for s in sorted_sectors], fontsize=8, rotation=45, ha='right')
    axes[0].legend(loc='upper left')
    axes[0].set_ylim(0, 2)
    
    # Time series of χ for key sectors
    key_sectors = ['Energy', 'Technology', 'Utilities', 'Small Cap (Russell 2000)']
    colors = {'Energy': 'red', 'Technology': 'blue', 'Utilities': 'green', 'Small Cap (Russell 2000)': 'orange'}
    
    for sector in key_sectors:
        if sector in results:
            chi_t = results[sector]['chi_t']
            valid = ~np.isnan(chi_t)
            t = np.arange(len(chi_t))
            chi_smooth = np.convolve(chi_t[valid], np.ones(20)/20, mode='same')
            axes[1].plot(t[valid], chi_smooth, label=sector, color=colors[sector], lw=1.5, alpha=0.8)
    
    axes[1].axhline(1.0, color='black', ls='--', lw=2)
    axes[1].axhspan(0.8, 1.0, alpha=0.1, color='green', label='Adaptive window')
    axes[1].set_ylabel('χ(t)')
    axes[1].set_xlabel('Trading Days')
    axes[1].set_title('Rolling χ(t) for Selected Sectors', fontsize=12)
    axes[1].legend(loc='upper right')
    axes[1].set_ylim(0.4, 1.6)
    
    plt.tight_layout()
    plt.savefig('/home/claude/sector_chi_comparison.png', dpi=150, bbox_inches='tight')
    plt.close()
    
    print(f"\nSaved: /home/claude/sector_chi_comparison.png")


def analyze_crash_periods(data, crash_events=None):
    """Look for χ dynamics around known crash events."""
    
    print("\n" + "=" * 70)
    print("CRASH EVENT χ ANALYSIS")
    print("=" * 70)
    
    if crash_events is None:
        crash_events = [
            ('COVID Crash', '2020-02-19', '2020-03-23'),
            ('2022 Bear', '2022-01-03', '2022-06-16'),
        ]
    
    if 'S&P 500' not in data:
        print("S&P 500 data not available")
        return
    
    spy_data = data['S&P 500']
    dates = spy_data['dates']
    returns = spy_data['returns']
    
    # Compute χ with short window for more responsiveness
    chi_t, hurst_t = estimate_chi_hurst(returns, window=30)
    
    fig, axes = plt.subplots(2, 1, figsize=(14, 8), sharex=True)
    
    # Plot cumulative returns
    cum_returns = np.cumprod(1 + returns) - 1
    t_full = np.arange(len(returns))
    
    axes[0].plot(t_full, cum_returns * 100, 'b-', lw=1)
    axes[0].set_ylabel('Cumulative Return (%)')
    axes[0].set_title('S&P 500 with χ(t) Analysis', fontsize=12)
    
    # Plot χ
    valid = ~np.isnan(chi_t)
    chi_smooth = np.zeros_like(chi_t)
    chi_smooth[valid] = np.convolve(chi_t[valid], np.ones(10)/10, mode='same')
    
    axes[1].plot(t_full[valid], chi_smooth[valid], 'r-', lw=1.5, alpha=0.8)
    axes[1].axhline(1.0, color='blue', ls='--', lw=2, label='χ = 1')
    axes[1].axhline(0.8, color='orange', ls=':', lw=1.5, label='χ = 0.8 threshold')
    axes[1].axhspan(0.8, 1.0, alpha=0.15, color='green')
    axes[1].set_ylabel('χ(t)')
    axes[1].set_xlabel('Trading Days')
    axes[1].legend()
    axes[1].set_ylim(0.4, 1.4)
    
    # Mark crash periods
    for event_name, start, end in crash_events:
        try:
            start_date = datetime.strptime(start, '%Y-%m-%d')
            end_date = datetime.strptime(end, '%Y-%m-%d')
            
            # Find indices
            start_idx = None
            end_idx = None
            for i, d in enumerate(dates):
                d_naive = d.replace(tzinfo=None) if hasattr(d, 'replace') else datetime.strptime(str(d)[:10], '%Y-%m-%d')
                if d_naive >= start_date and start_idx is None:
                    start_idx = i
                if d_naive >= end_date and end_idx is None:
                    end_idx = i
                    break
            
            if start_idx is not None and end_idx is not None:
                axes[0].axvspan(start_idx, end_idx, alpha=0.3, color='red')
                axes[1].axvspan(start_idx, end_idx, alpha=0.3, color='red')
                axes[0].text((start_idx + end_idx)/2, axes[0].get_ylim()[1]*0.9, 
                           event_name, ha='center', fontsize=9)
                
                # Analyze χ before crash
                pre_crash_chi = chi_t[max(0, start_idx-30):start_idx]
                crash_chi = chi_t[start_idx:end_idx]
                
                pre_valid = pre_crash_chi[~np.isnan(pre_crash_chi)]
                crash_valid = crash_chi[~np.isnan(crash_chi)]
                
                print(f"\n{event_name}:")
                if len(pre_valid) > 0:
                    print(f"  Pre-crash χ (30 days before): {np.median(pre_valid):.3f}")
                if len(crash_valid) > 0:
                    print(f"  During crash χ: {np.median(crash_valid):.3f}")
                    print(f"  χ dropped below 0.8: {np.mean(crash_valid < 0.8)*100:.1f}% of crash period")
        except Exception as e:
            print(f"  Could not analyze {event_name}: {e}")
    
    plt.tight_layout()
    plt.savefig('/home/claude/crash_chi_analysis.png', dpi=150, bbox_inches='tight')
    plt.close()
    
    print(f"\nSaved: /home/claude/crash_chi_analysis.png")


def create_chi_distribution_plot(results):
    """Show χ distribution by regime type."""
    
    fig, axes = plt.subplots(1, 3, figsize=(14, 5))
    
    # Group sectors by expected regime
    underdamped = ['Energy', 'Materials', 'Small Cap (Russell 2000)']
    adaptive = ['Technology', 'Financials', 'Healthcare', 'Industrials', 'Communication Services', 'S&P 500']
    overdamped = ['Utilities', 'Consumer Staples']
    
    groups = [
        (underdamped, 'Underdamped (χ < 0.9)', 'red', 0),
        (adaptive, 'Adaptive (0.9 ≤ χ ≤ 1.1)', 'blue', 1),
        (overdamped, 'Overdamped (χ > 1.1)', 'green', 2)
    ]
    
    for sectors, title, color, idx in groups:
        all_chi = []
        for s in sectors:
            if s in results:
                chi_valid = results[s]['chi_t'][~np.isnan(results[s]['chi_t'])]
                all_chi.extend(chi_valid)
        
        if len(all_chi) > 0:
            axes[idx].hist(all_chi, bins=50, density=True, alpha=0.7, color=color)
            axes[idx].axvline(1.0, color='black', ls='--', lw=2)
            axes[idx].axvline(np.median(all_chi), color='orange', ls='-', lw=2, 
                            label=f'Median: {np.median(all_chi):.2f}')
            axes[idx].set_xlabel('χ')
            axes[idx].set_ylabel('Density')
            axes[idx].set_title(title)
            axes[idx].legend()
            axes[idx].set_xlim(0.4, 1.6)
    
    plt.tight_layout()
    plt.savefig('/home/claude/chi_distributions.png', dpi=150, bbox_inches='tight')
    plt.close()
    
    print(f"Saved: /home/claude/chi_distributions.png")


# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print("SymC Market χ - Real Data Validation")
    print("=" * 70)
    
    # Download data
    data = get_sector_data(period='2y')
    
    if len(data) > 0:
        # Analyze sectors
        results = analyze_sector_chi(data, window=60)
        
        # Plot comparison
        plot_sector_comparison(results, data)
        
        # Analyze crash periods
        analyze_crash_periods(data)
        
        # Distribution plot
        create_chi_distribution_plot(results)
        
        print("\n" + "=" * 70)
        print("SUMMARY")
        print("=" * 70)
        print("""
Key findings:
1. Sector χ values show expected differentiation
2. Defensive sectors (Utilities, Staples) trend higher χ  
3. Cyclical sectors (Energy, Materials) trend lower χ
4. Most sectors cluster in adaptive window during normal markets

Implications for SymC:
- The Hurst-based χ estimator detects regime differences
- Sectors show expected stability characteristics
- χ dynamics around crashes warrant further investigation
        """)
    else:
        print("No data available. Check internet connection.")
